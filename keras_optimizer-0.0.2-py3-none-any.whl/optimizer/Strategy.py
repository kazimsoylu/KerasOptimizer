from enum import Enum

class Strategy(Enum):
    MAXIMIZE=1
    MINIMIZE=2